<?php include('includes/head.php'); ?>
<?php  


?>
<body>
	
	<div id="page">
		
<?php include('includes/navigasi.php'); ?>
	<!-- /header -->
		
	<main>
	    <div class="container margin_30">
	
		<!--/carousel-->
        </div>
	
		
	
		<!-- /container -->

		
		<!-- /featured -->

	
		<!-- /container -->
		
	<?php echo "Pembayaran Belum Berhasil Silakan Coba Lagi";?>
		<!-- /bg_gray -->

	
		<!-- /container -->
	</main>
	<!-- /main -->
	
<?php include('includes/footer.php'); ?>

	<!--/footer-->
	</div>
	<!-- page -->
	
	<div id="toTop"></div><!-- Back to top button -->
	
	<!-- COMMON SCRIPTS -->
    <script src="js/common_scripts.min.js"></script>
    <script src="js/main.js"></script>
	
	<!-- SPECIFIC SCRIPTS -->
	<script src="js/carousel-home.min.js"></script>

</body>
</html>