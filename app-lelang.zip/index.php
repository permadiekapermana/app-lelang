
<?php
  header('location:client'); 
?>